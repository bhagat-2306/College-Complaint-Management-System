this is java project using swing and AWT.. It takes complains from users and allows an Admin to access the complaint and resolve it. User and Admin have to login to access the system.

//Procedure

install apache netbeans...
open the project file named Complaint System..
open the file with the name JavaApplication4.java in src..
cick on the Run Button or press f6
Login details for the user are : ID: 016@iiita.ac.in   Password: 789
				 ID: 017@iiita.ac.in   Password: 456
				 ID: 034@iiita.ac.in   Password: 000
				 ID: 076@iiita.ac.in   Password: 123

Login details for the Admin is:  ID: admin@iiita.ac.in Password: Admin

Login with the user to lodge and view contents, login with the Admin to resolve complaints and add new users.



