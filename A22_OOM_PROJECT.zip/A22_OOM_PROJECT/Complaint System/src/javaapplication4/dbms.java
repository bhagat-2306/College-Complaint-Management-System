/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaapplication4;
import java.util.ArrayList;
/**
 *
 * @author Prernendu Bhagat
 */

import java.util.ArrayList;
import java.util.Arrays;

public class dbms {
    //public ArrayList<String> sname = new ArrayList<String>();
    static ArrayList<String> sname = new ArrayList<String>(Arrays.asList("Priyal","Mansa","Bhagat","Amit"));
    static ArrayList<String> id = new ArrayList<String>(Arrays.asList("076@iiita.ac.in", "017@iiita.ac.in","016@iiita.ac.in","034@iiita.ac.in"));
    static ArrayList<String> pswd = new ArrayList<String>(Arrays.asList("123","456","789","000"));

    static ArrayList<String> admin_name = new ArrayList<String>(Arrays.asList("Admin1"));
    static ArrayList<String> admin_id = new ArrayList<String>(Arrays.asList("Admin1@bennett.edu.in"));
    static ArrayList<String> admin_pswd = new ArrayList<String>(Arrays.asList("Admin1"));

    static ArrayList<Integer> comp_no = new ArrayList<Integer>();
    static ArrayList<String> dscrptn = new ArrayList<String>();
    static ArrayList<String> status = new ArrayList<String>();

//    public void login_cred(String s_id, String s_pswd){
//        if(Arrays.asList(id).contains(s_id)){
//            int n = id.indexOf(s_id);
//            if(pswd.get(n).equals(s_pswd)){
//
//            }
//        }
//    }
//    public static void main(String[] args) {
//        System.out.println(id);
//    }
}
